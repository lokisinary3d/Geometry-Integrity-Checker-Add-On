# ui.py

import bpy
from bpy.types import Panel
from .operators import GI_OT_ScanMesh, GI_OT_SelectDuplicates, GI_OT_RemoveDuplicates, GI_OT_ResetChecker
from . import bl_info

class GI_PT_GeometryIntegrity(Panel):
    """Creates a Panel in the N-Panel of the 3D Viewport"""
    bl_label = "Geometry Integrity Checker"
    bl_idname = "GI_PT_GeometryIntegrity"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Geometry Integrity'
    bl_author = bl_info["author"]
    bl_version = bl_info["version"]

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Panel Header
        header_row = layout.row()
        split = header_row.split(factor=0.8)
        split.label(text="Geometry Integrity Checker", icon='CHECKBOX_HLT')
        split.operator("geometry_integrity.reset_checker", text="Reset", icon='FILE_REFRESH')

        layout.separator()

        # Geometry Detection Settings
        col = layout.column(align=True)
        col.prop(scene, "gi_threshold")
        col.prop(scene, "gi_detect_duplicates")
        col.prop(scene, "gi_detect_near_duplicates")
        col.prop(scene, "gi_automate_scans", text="Enable Automated Scans")
        col.prop(scene, "gi_scan_interval", text="Interval (Seconds)")
        # Manual Scan
        col = layout.column(align=True)
        col.operator("geometry_integrity.scan_mesh", text="Scan Mesh", icon='MOD_VERTEX_WEIGHT')

        # Display Results with Expand/Collapse
        gi_objects_duplicates = scene.gi_objects_duplicates
        if gi_objects_duplicates:
            for obj_dup in gi_objects_duplicates:
                box = layout.box()
                row = box.row()

                # Expand/Collapse Toggle
                icon = 'TRIA_DOWN' if obj_dup.expanded else 'TRIA_RIGHT'
                row.prop(obj_dup, "expanded", text="", icon=icon, emboss=False)

                # Object Label
                row.label(text=f"Object: {obj_dup.object_name}", icon='MESH_CUBE')

                # Expanded Content
                if obj_dup.expanded:
                    dup_verts = len(obj_dup.duplicate_verts)
                    dup_edges = len(obj_dup.duplicate_edges)
                    dup_faces = len(obj_dup.duplicate_faces)

                    if dup_verts > 0 or dup_edges > 0 or dup_faces > 0:
                        box.label(text=f"Vertices: {dup_verts}")
                        box.label(text=f"Edges: {dup_edges}")
                        box.label(text=f"Faces: {dup_faces}")
                    else:
                        box.label(text="No duplicates found.", icon='INFO')

            # Action Buttons
            row = layout.row()
            row.operator("geometry_integrity.select_duplicates", text="Select Duplicates", icon='SELECT_SET')
            row.operator("geometry_integrity.remove_duplicates", text="Remove Duplicates", icon='TRASH')
        else:
            layout.label(text="No scan results available. Please perform a scan.", icon='INFO')



        # Add a row for the "Info" section with a toggleable button
        info_row = layout.row()
        info_row.prop(context.scene, "show_info", toggle=True, text="Info", icon='INFO' if context.scene.show_info else 'FILE_TICK')

        # Show additional information if the toggle is enabled
        if context.scene.show_info:
            info_layout = layout.box().column()
            info_layout.label(icon='USER', text=f"Author: {self.bl_author}")
            version = ".".join(str(num) for num in self.bl_version)  # Convert tuple to string with dot as separator
            info_layout.label(icon='TEXT', text=f"Version: {version}")
            
            # Add buttons to display the README and License in the same row
            row = info_layout.row(align=True)
            row.alignment = 'LEFT'  # Align the buttons to the left
            row.operator("object.display_readme", text="Readme", icon='HELP', emboss=False)
            row.operator("object.display_license", text="License", icon='COPY_ID', emboss=False)

            # Add a button to display the Privacy and Terms in the same row
            row = info_layout.row(align=True)
            row.alignment = 'LEFT'  # Align the button to the left
            row.operator("object.display_privacy_policy", text="Privacy Policy", icon='LOCKED', emboss=False)
            row.operator("object.display_terms_and_conditions", text="Terms And Conditions", icon='BOOKMARKS', emboss=False)