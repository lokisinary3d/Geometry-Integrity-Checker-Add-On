# properties.py

import bpy
from bpy.props import (
    FloatProperty,
    BoolProperty,
    CollectionProperty,
    IntProperty,
    StringProperty,
)

from bpy.types import PropertyGroup


# Define Property Groups to store duplicates
class GI_DuplicateVert(PropertyGroup):
    index: IntProperty(name="Vertex Index")


class GI_DuplicateEdge(PropertyGroup):
    index: IntProperty(name="Edge Index")


class GI_DuplicateFace(PropertyGroup):
    index: IntProperty(name="Face Index")


class GI_ObjectDuplicates(PropertyGroup):
    """Stores duplicates for a single mesh object."""
    object_name: StringProperty(name="Object Name")
    duplicate_verts: CollectionProperty(type=GI_DuplicateVert)
    duplicate_edges: CollectionProperty(type=GI_DuplicateEdge)
    duplicate_faces: CollectionProperty(type=GI_DuplicateFace)
    expanded: BoolProperty(name="Expanded", default=False)

def toggle_automate_scans(self, context):
    """Start or stop automated scans based on toggle state."""
    if context.scene.gi_automate_scans:
        bpy.ops.geometry_integrity.automate_scans('EXEC_DEFAULT')
    else:
        bpy.ops.geometry_integrity.automate_scans('EXEC_DEFAULT')

# Define Scene Properties
def register_properties():
    bpy.types.Scene.gi_objects_duplicates = CollectionProperty(type=GI_ObjectDuplicates)
    bpy.types.Scene.gi_duplicate_verts = CollectionProperty(type=GI_DuplicateVert)
    bpy.types.Scene.gi_duplicate_edges = CollectionProperty(type=GI_DuplicateEdge)
    bpy.types.Scene.gi_duplicate_faces = CollectionProperty(type=GI_DuplicateFace)
    bpy.types.Scene.gi_threshold = FloatProperty(
        name="Threshold",
        description="Proximity threshold for near-duplicates",
        default=0.0001,  # Increased precision
        min=0.0,
        max=1.0,
        precision=6,
    )
    bpy.types.Scene.gi_detect_duplicates = BoolProperty(
        name="Detect Duplicates",
        description="Check for exact duplicate vertices, edges, and faces",
        default=True,
    )
    bpy.types.Scene.gi_detect_near_duplicates = BoolProperty(
        name="Detect Near-Duplicates",
        description="Check for elements within a proximity threshold",
        default=True,
    )
    bpy.types.Scene.gi_show_scan_warning = BoolProperty(
        name="Show Scan Warning",
        description="Display warning before scanning meshes",
        default=True,
    )

    bpy.types.Scene.gi_automate_scans = BoolProperty(
        name="Automate Scans",
        description="Enable automated scanning at regular intervals",
        default=False,
        update=toggle_automate_scans,  # Call the operator when the toggle changes
    )
    bpy.types.Scene.gi_scan_interval = FloatProperty(
        name="Scan Interval (Seconds)",
        description="Time interval between automated scans",
        default=10.0,
        min=1.0,
        precision=1,
    )
    
    bpy.types.Scene.show_info = BoolProperty(
        name="Show Info",
        description="Toggle to show or hide information",
        default=False,
    )

def unregister_properties():
    del bpy.types.Scene.gi_objects_duplicates
    del bpy.types.Scene.gi_duplicate_verts
    del bpy.types.Scene.gi_duplicate_edges
    del bpy.types.Scene.gi_duplicate_faces
    del bpy.types.Scene.gi_threshold
    del bpy.types.Scene.gi_detect_duplicates
    del bpy.types.Scene.gi_detect_near_duplicates
    del bpy.types.Scene.gi_show_scan_warning
    del bpy.types.Scene.gi_automate_scans
    del bpy.types.Scene.gi_scan_interval
    del bpy.types.Scene.show_info