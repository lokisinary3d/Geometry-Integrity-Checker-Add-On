# __init__.py

bl_info = {
    "name": "Geometry Integrity Checker",
    "author": "lokisinary",
    "version": (1, 0),
    "blender": (4, 3, 0),
    "location": "View3D > N-Panel > Geometry Integrity",
    "description": "Detects duplicate or closely situated vertices, edges, and faces in multiple mesh objects.",
    "warning": "",
    "wiki_url": "",
    "category": "Mesh",
    "doc_url": "https://github.com/lokisinary3d/Geometry-Integrity-Checker-Add-On",  # Documentation URL
    "website_url": "https://sinary.org/",  # Official Website
}
version = bl_info["version"]

import os
print(os.path.basename(os.path.dirname(__file__)))
import bpy
from bpy.types import AddonPreferences
from bpy.props import BoolProperty
from .properties import (
    GI_DuplicateVert,
    GI_DuplicateEdge,
    GI_DuplicateFace,
    GI_ObjectDuplicates,
    register_properties,
    unregister_properties,
)
from .operators import (
    GI_OT_ScanMesh,
    GI_OT_SelectDuplicates,
    GI_OT_RemoveDuplicates,
    GI_OT_ResetChecker,
    GI_OT_AutomateScans,
)
from .ui import (
    GI_PT_GeometryIntegrity,
)

from .readme import OBJECT_OT_DisplayReadmeOperator
from .privacy_policy import OBJECT_OT_DisplayPrivacyPolicyOperator
from .license import OBJECT_OT_DisplayLicenseOperator
from .terms_and_conditions import OBJECT_OT_DisplayTermsAndConditionsOperator


# Add-on Preferences for Community Engagement
class GeometryIntegrityCheckerAddonPreferences(AddonPreferences):
    bl_idname = __name__

    # Property for collapsible preferences
    show_preferences: BoolProperty(
        name="Show Preferences",
        description="Expand or collapse the preferences section",
        default=True
    )

    def draw(self, context):
        layout = self.layout

        # Collapsible preferences section
        row = layout.row()
        row.prop(self, "show_preferences", icon="TRIA_DOWN" if self.show_preferences else "TRIA_RIGHT", emboss=False)

        if self.show_preferences:
            # Add-on Information
            layout.label(text="Geometry Integrity Checker Addon Preferences", icon='PREFERENCES')

            # Documentation URL
            doc_url = bl_info.get("doc_url")
            if doc_url:
                layout.operator("wm.url_open", text="GitHub", icon="HELP").url = doc_url

            # Website URL
            website_url = bl_info.get("website_url")
            if website_url:
                layout.operator("wm.url_open", text="Visit Website", icon="URL").url = website_url

classes = (
    GI_DuplicateVert,
    GI_DuplicateEdge,
    GI_DuplicateFace,
    GI_ObjectDuplicates,
    GI_OT_ScanMesh,
    GI_OT_SelectDuplicates,
    GI_OT_RemoveDuplicates,
    GI_OT_ResetChecker,  # Add to the classes tuple
    GI_PT_GeometryIntegrity,
    GI_OT_AutomateScans,
    OBJECT_OT_DisplayReadmeOperator,
    OBJECT_OT_DisplayPrivacyPolicyOperator,
    OBJECT_OT_DisplayLicenseOperator,
    OBJECT_OT_DisplayTermsAndConditionsOperator,
    GeometryIntegrityCheckerAddonPreferences,
)

def register():
    print("Registering Geometry Integrity Checker")
    for cls in classes:
        bpy.utils.register_class(cls)
    register_properties()



def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            print(f"Class {cls.__name__} could not be unregistered.")
    unregister_properties()


if __name__ == "__main__":
    register()