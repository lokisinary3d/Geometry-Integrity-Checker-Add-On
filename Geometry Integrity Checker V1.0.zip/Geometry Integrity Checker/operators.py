# operators.py

import bpy
import bmesh
from bpy.app import timers
from bpy.types import Operator
from bpy.props import BoolProperty
from .properties import (
    GI_ObjectDuplicates,
    GI_DuplicateVert,
    GI_DuplicateEdge,
    GI_DuplicateFace,
)
from mathutils import kdtree


class GI_OT_ScanMesh(Operator):
    """Scan all selected mesh objects for duplicate or near-duplicate geometry."""
    bl_idname = "geometry_integrity.scan_mesh"
    bl_label = "Scan Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    # This property will capture the state of the "Don't show again" checkbox
    dont_show_again: BoolProperty(
        name="Don't show this warning again",
        default=False
    )

    def invoke(self, context, event):
        # Check if the user has opted out of the warning
        if not context.scene.gi_show_scan_warning:
            return self.execute(context)

        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=500)  # Increased width for better visibility

    def draw(self, context):
        layout = self.layout

        # Create a box to contain the warning message and checkbox
        box = layout.box()
        box.label(text="⚠️ Please save your work before scanning the mesh.", icon='ERROR')
        box.separator()
        box.label(text="🔄 If the scan modifies the mesh, you can use Ctrl+Z to undo the changes.", icon='INFO')
        box.separator()

        # Add the "Don't show again" checkbox
        box.prop(self, "dont_show_again", text="Don't show this warning again")

    def execute(self, context):
        # If the user checked "Don't show again", update the scene property
        if self.dont_show_again:
            context.scene.gi_show_scan_warning = False

        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if not selected_objects:
            self.report({'ERROR'}, "No mesh objects selected.")
            return {'CANCELLED'}

        # Clear previous duplicates
        context.scene.gi_objects_duplicates.clear()

        for obj in selected_objects:
            print(f"Scanning Object: {obj.name}")
            bm = bmesh.new()
            bm.from_mesh(obj.data)

            duplicates = {
                'vertices': set(),
                'edges': set(),
                'faces': set()
            }

            # Duplicate Vertices Detection
            if context.scene.gi_detect_duplicates or context.scene.gi_detect_near_duplicates:
                print(f"Starting Vertex Detection for {obj.name}...")
                verts = [v.co.copy() for v in bm.verts]
                vertex_tree = kdtree.KDTree(len(verts))
                for i, v in enumerate(verts):
                    vertex_tree.insert(v, i)
                vertex_tree.balance()

                # Exact duplicates
                if context.scene.gi_detect_duplicates:
                    seen = {}
                    for v in bm.verts:
                        key = tuple(round(coord, 6) for coord in v.co)
                        if key in seen:
                            duplicates['vertices'].add(v.index)
                            print(f"Duplicate Vertex Found in {obj.name}: Index {v.index}")
                        else:
                            seen[key] = v.index

                # Near duplicates
                if context.scene.gi_detect_near_duplicates:
                    for v in bm.verts:
                        if v.index in duplicates['vertices']:
                            continue
                        nearby = vertex_tree.find_range(v.co, context.scene.gi_threshold)
                        for item in nearby:
                            if isinstance(item, (tuple, list)) and len(item) >= 2:
                                idx, dist = item[:2]
                                if idx != v.index and 1e-6 < dist <= context.scene.gi_threshold:
                                    duplicates['vertices'].add(v.index)
                                    print(f"Near-Duplicate Vertex Found in {obj.name}: Index {v.index}, Distance {dist}")
                                    break

            # Duplicate Edges Detection
            if context.scene.gi_detect_duplicates:
                print(f"Starting Edge Detection for {obj.name}...")
                edge_signatures = {}
                for e in bm.edges:
                    sig = tuple(sorted([tuple(round(coord, 6) for coord in v.co) for v in e.verts]))
                    if sig in edge_signatures:
                        duplicates['edges'].add(e.index)
                        print(f"Duplicate Edge Found in {obj.name}: Index {e.index}")
                    else:
                        edge_signatures[sig] = e.index

            # Duplicate Faces Detection
            if context.scene.gi_detect_duplicates:
                print(f"Starting Face Detection for {obj.name}...")
                face_signatures = {}
                for f in bm.faces:
                    sig = tuple(sorted([tuple(round(coord, 6) for coord in v.co) for v in f.verts]))
                    if sig in face_signatures:
                        duplicates['faces'].add(f.index)
                        print(f"Duplicate Face Found in {obj.name}: Index {f.index}")
                    else:
                        face_signatures[sig] = f.index

            print(f"Total Duplicate Vertices Detected in {obj.name}: {len(duplicates['vertices'])}")
            print(f"Total Duplicate Edges Detected in {obj.name}: {len(duplicates['edges'])}")
            print(f"Total Duplicate Faces Detected in {obj.name}: {len(duplicates['faces'])}")

            # Populate the scene properties
            gi_obj_dup = context.scene.gi_objects_duplicates.add()
            gi_obj_dup.object_name = obj.name

            for v_idx in duplicates['vertices']:
                item = gi_obj_dup.duplicate_verts.add()
                item.index = v_idx

            for e_idx in duplicates['edges']:
                item = gi_obj_dup.duplicate_edges.add()
                item.index = e_idx

            for f_idx in duplicates['faces']:
                item = gi_obj_dup.duplicate_faces.add()
                item.index = f_idx

            bm.free()

        # Report the overall scan results
        total_dups = sum(
            len(obj_dup.duplicate_verts) +
            len(obj_dup.duplicate_edges) +
            len(obj_dup.duplicate_faces)
            for obj_dup in context.scene.gi_objects_duplicates
        )
        if total_dups == 0:
            self.report({'INFO'}, "Scan complete: No duplicates found in selected objects.")
        else:
            self.report({'INFO'}, f"Scan complete: {total_dups} duplicates found across selected objects.")
        return {'FINISHED'}

class GI_OT_AutomateScans(Operator):
    """Control the automated scans based on the toggle state."""
    bl_idname = "geometry_integrity.automate_scans"
    bl_label = "Automate Scans"

    _timer = None  # Store the timer handle

    def execute(self, context):
        # Start or stop automated scans based on the toggle state
        if context.scene.gi_automate_scans:
            self.report({'INFO'}, "Automated scanning started.")
            self.start_timer(context)
        else:
            self.report({'INFO'}, "Automated scanning stopped.")
            self.stop_timer(context)
        return {'FINISHED'}

    def start_timer(self, context):
        """Register the timer for automated scans."""
        self._timer = bpy.app.timers.register(self.run_automated_scan, first_interval=context.scene.gi_scan_interval)

    def stop_timer(self, context):
        """Unregister the timer to stop automated scans."""
        if self._timer:
            bpy.app.timers.unregister(self._timer)
            self._timer = None

    def run_automated_scan(self):
        """Perform an automated scan and re-register the timer if the toggle is still on."""
        context = bpy.context
        if not context.scene.gi_automate_scans:
            return None  # Stop the timer if automation is off

        # Execute a scan
        bpy.ops.geometry_integrity.scan_mesh()

        # Re-register the timer for the next scan
        return context.scene.gi_scan_interval

class GI_OT_SelectDuplicates(Operator):
    """Select duplicate geometry in all scanned mesh objects."""
    bl_idname = "geometry_integrity.select_duplicates"
    bl_label = "Select Duplicates"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        gi_objects_duplicates = context.scene.gi_objects_duplicates

        if not gi_objects_duplicates:
            self.report({'WARNING'}, "No duplicates to select. Please run a scan first.")
            return {'CANCELLED'}

        for obj_dup in gi_objects_duplicates:
            obj = bpy.data.objects.get(obj_dup.object_name)
            if obj is None or obj.type != 'MESH':
                print(f"Object {obj_dup.object_name} not found or is not a mesh.")
                continue

            print(f"Selecting duplicates in {obj.name}...")
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bm = bmesh.from_edit_mesh(obj.data)

            # Ensure lookup tables are up-to-date
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            # Deselect all
            bpy.ops.mesh.select_all(action='DESELECT')

            # Select duplicate vertices
            if obj_dup.duplicate_verts:
                bpy.ops.mesh.select_mode(type="VERT")
                for v in obj_dup.duplicate_verts:
                    if v.index < len(bm.verts):
                        bm.verts[v.index].select_set(True)
                    else:
                        print(f"Vertex index {v.index} out of range for object {obj.name}.")

            # Select duplicate edges
            if obj_dup.duplicate_edges:
                bpy.ops.mesh.select_mode(type="EDGE")
                for e in obj_dup.duplicate_edges:
                    if e.index < len(bm.edges):
                        bm.edges[e.index].select_set(True)
                    else:
                        print(f"Edge index {e.index} out of range for object {obj.name}.")

            # Select duplicate faces
            if obj_dup.duplicate_faces:
                bpy.ops.mesh.select_mode(type="FACE")
                for f in obj_dup.duplicate_faces:
                    if f.index < len(bm.faces):
                        bm.faces[f.index].select_set(True)
                    else:
                        print(f"Face index {f.index} out of range for object {obj.name}.")

            # Update the mesh with the new selections
            bmesh.update_edit_mesh(obj.data)
            bpy.ops.object.mode_set(mode='OBJECT')  # Exit Edit Mode

        self.report({'INFO'}, "Duplicates selected across all scanned objects.")
        return {'FINISHED'}


class GI_OT_RemoveDuplicates(Operator):
    """Remove duplicate geometry from all scanned mesh objects."""
    bl_idname = "geometry_integrity.remove_duplicates"
    bl_label = "Remove Duplicates"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        gi_objects_duplicates = context.scene.gi_objects_duplicates

        if not gi_objects_duplicates:
            self.report({'WARNING'}, "No duplicates to remove. Please run a scan first.")
            return {'CANCELLED'}

        for obj_dup in gi_objects_duplicates:
            obj = bpy.data.objects.get(obj_dup.object_name)
            if obj is None or obj.type != 'MESH':
                print(f"Object {obj_dup.object_name} not found or is not a mesh.")
                continue

            print(f"Removing duplicates in {obj.name}...")
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bm = bmesh.from_edit_mesh(obj.data)

            # Perform remove doubles using BMesh
            bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=context.scene.gi_threshold)

            # Update the mesh with the changes
            bmesh.update_edit_mesh(obj.data)

            bpy.ops.object.mode_set(mode='OBJECT')  # Exit Edit Mode

        # Clear duplicates after removal
        context.scene.gi_objects_duplicates.clear()

        self.report({'INFO'}, "Duplicates removed across all scanned objects.")
        return {'FINISHED'}


class GI_OT_ResetChecker(Operator):
    """Reset the Geometry Integrity Checker to its default state."""
    bl_idname = "geometry_integrity.reset_checker"
    bl_label = "Reset Geometry Integrity Checker"
    bl_options = {'REGISTER', 'UNDO'}

    confirm_reset: BoolProperty(
        name="Confirm Reset",
        default=False
    )

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Are you sure you want to reset the Geometry Integrity Checker?", icon='QUESTION')
        box.prop(self, "confirm_reset", text="Yes, reset now")

    def execute(self, context):
        if not self.confirm_reset:
            self.report({'INFO'}, "Reset cancelled.")
            return {'CANCELLED'}

        # Reset Scene Properties to default values
        context.scene.gi_threshold = 0.0001
        context.scene.gi_detect_duplicates = True
        context.scene.gi_detect_near_duplicates = True
        context.scene.gi_show_scan_warning = True
        context.scene.gi_automate_scans = False
        context.scene.gi_scan_interval = 10.0
        # Clear all duplicate detection data
        context.scene.gi_objects_duplicates.clear()

        self.report({'INFO'}, "Geometry Integrity Checker has been reset to its default state.")
        return {'FINISHED'}