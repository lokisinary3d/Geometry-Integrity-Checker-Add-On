import os

def write_directory_structure(base_dir, output_file, exclude_names=("blender_manual", "__pycache__", ".venv", ".vs", ".vscode")):
    """
    Generates a hierarchical directory structure for the specified directory
    and writes it to a text file, excluding specific directories or files.
    """
    with open(output_file, "w") as f:
        for root, dirs, files in os.walk(base_dir):
            # Exclude directories and files with specified names
            dirs[:] = [d for d in dirs if d not in exclude_names]
            files = [file for file in files if file not in exclude_names]
            
            # Calculate the depth for indentation
            level = root.replace(base_dir, "").count(os.sep)
            indent = " " * 4 * level  # Indent with 4 spaces per level
            f.write(f"{indent}{os.path.basename(root)}/\n")
            sub_indent = " " * 4 * (level + 1)
            for file in files:
                f.write(f"{sub_indent}{file}\n")

if __name__ == "__main__":
    base_directory = input("Enter the base directory path: ").strip()
    output_file = "directory_structure.txt"
    
    if os.path.exists(base_directory):
        write_directory_structure(base_directory, output_file)
        print(f"Directory structure saved to {output_file}")
    else:
        print(f"Error: Directory '{base_directory}' does not exist.")
